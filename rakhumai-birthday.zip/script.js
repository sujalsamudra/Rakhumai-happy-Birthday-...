function revealSurprise() {
    document.getElementById("surprise").style.display = "block";
    document.getElementById("bgMusic").play();
}